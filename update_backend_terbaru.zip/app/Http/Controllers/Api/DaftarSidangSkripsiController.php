<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\UploudSuratToDrive;
use App\Models\DaftarSidangSkripsi;
use App\Models\DokumenSkripsi;
use App\Models\Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class DaftarSidangSkripsiController extends Controller
{
    /**
     * Menampilkan daftar pendaftaran sidang skripsi.
     */
    public function index(Request $request)
    {
        $query = DaftarSidangSkripsi::with(['dokumen', 'prodiRel']);

        $user = Auth::user();
        $userProdi = $user?->prodi ?: ($user?->prodi_id ? Prodi::find($user->prodi_id) : null);

        if ($userProdi) {
            // Scope Prodi jika user login terafiliasi dengan prodi tertentu (Staff)
            $query->where(function ($q) use ($userProdi) {
                $q->where('prodi_id', $userProdi->id)
                  ->orWhere('prodi', $userProdi->nama)
                  ->orWhere('prodi', $userProdi->alias)
                  ->orWhereRaw('LOWER(TRIM(prodi)) = ?', [strtolower(trim($userProdi->nama))])
                  ->orWhereRaw('LOWER(TRIM(prodi)) = ?', [strtolower(trim($userProdi->alias))]);
            });
        } elseif ($request->filled('prodi_id')) {
            // Filter Prodi dari Request (untuk Admin / BAAK yang tidak terafiliasi prodi)
            $prodiFilter = Prodi::find($request->prodi_id);
            $query->where(function ($q) use ($request, $prodiFilter) {
                $q->where('prodi_id', $request->prodi_id);
                if ($prodiFilter) {
                    $q->orWhere('prodi', $prodiFilter->nama)
                      ->orWhere('prodi', $prodiFilter->alias)
                      ->orWhereRaw('LOWER(TRIM(prodi)) = ?', [strtolower(trim($prodiFilter->nama))])
                      ->orWhereRaw('LOWER(TRIM(prodi)) = ?', [strtolower(trim($prodiFilter->alias))]);
                }
            });
        }

        // Search Filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama', 'like', "%{$search}%")
                  ->orWhere('nim', 'like', "%{$search}%")
                  ->orWhere('nik', 'like', "%{$search}%")
                  ->orWhere('prodi', 'like', "%{$search}%")
                  ->orWhere('judul_skripsi', 'like', "%{$search}%");
            });
        }

        // Sorting
        $sortBy = $request->input('sortBy', 'id');
        $sortType = $request->input('sortType', 'desc');
        $query->orderBy($sortBy, $sortType);

        // Pagination
        $limit = (int) $request->input('limit', 10);
        $data = $query->paginate($limit);

        return response()->json([
            'status' => true,
            'data' => $data,
            'message' => 'Data pendaftaran sidang skripsi berhasil diambil'
        ]);
    }

    /**
     * Menyimpan data pendaftaran sidang skripsi baru beserta dokumen pendukung.
     */
    public function store(Request $request)
    {
        Log::info('DaftarSidangSkripsi store request', $request->except(['dokumen_files']));

        $validator = Validator::make($request->all(), [
            'nama'           => 'required|string|max:255',
            'nim'            => 'required|string|max:50',
            'nik'            => 'nullable|string|max:50',
            'prodi'          => 'required|string|max:255',
            'prodi_id'       => 'nullable|integer',
            'judul_skripsi'  => 'required|string',
            'periode_sidang' => 'required|date',
            'dospem1'        => 'nullable|string|max:255',
            'dospem2'        => 'nullable|string|max:255',
            'pembimbing1'    => 'nullable|string|max:255',
            'pembimbing2'    => 'nullable|string|max:255',
            'dokumen'        => 'nullable|array',
            'dokumen.*.nama_dokumen' => 'nullable|string|max:255',
            'dokumen_files.*'        => 'nullable|file|max:20480', // Maksimal 20MB per file
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();
        try {
            $validated = $validator->validated();

            // Set user_id
            $validated['user_id'] = Auth::id();

            // Sinkronisasi prodi_id jika belum terisi
            if (empty($validated['prodi_id'])) {
                $prodiModel = Prodi::where('nama', $validated['prodi'])
                    ->orWhere('alias', $validated['prodi'])
                    ->first();
                if ($prodiModel) {
                    $validated['prodi_id'] = $prodiModel->id;
                }
            }

            $pembimbing1 = $validated['pembimbing1'] ?? ($validated['dospem1'] ?? null);
            $pembimbing2 = $validated['pembimbing2'] ?? ($validated['dospem2'] ?? null);

            $daftarSidang = DaftarSidangSkripsi::create([
                'nama'           => $validated['nama'],
                'nim'            => $validated['nim'],
                'nik'            => $validated['nik'] ?? null,
                'prodi'          => $validated['prodi'],
                'prodi_id'       => $validated['prodi_id'] ?? null,
                'judul_skripsi'  => $validated['judul_skripsi'],
                'periode_sidang' => $validated['periode_sidang'],
                'pembimbing1'    => $pembimbing1,
                'pembimbing2'    => $pembimbing2,
                'user_id'        => $validated['user_id'],
            ]);

            // Simpan dokumen jika ada yang diunggah
            $this->handleDocumentUploads($request, $daftarSidang);

            DB::commit();

            $daftarSidang->load('dokumen');

            return response()->json([
                'status' => true,
                'data' => $daftarSidang,
                'message' => 'Pendaftaran sidang skripsi berhasil disimpan'
            ], 201);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Error storing DaftarSidangSkripsi: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'status' => false,
                'message' => 'Terjadi kesalahan saat menyimpan data: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Menampilkan detail pendaftaran sidang skripsi.
     */
    public function show($id)
    {
        $data = DaftarSidangSkripsi::with('dokumen')->find($id);

        if (!$data) {
            return response()->json([
                'status' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $data,
            'message' => 'Data berhasil diambil'
        ]);
    }

    /**
     * Mengupdate data pendaftaran sidang skripsi.
     */
    public function update(Request $request, $id)
    {
        $daftarSidang = DaftarSidangSkripsi::find($id);

        if (!$daftarSidang) {
            return response()->json([
                'status' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'nama'           => 'required|string|max:255',
            'nim'            => 'required|string|max:50',
            'nik'            => 'nullable|string|max:50',
            'prodi'          => 'required|string|max:255',
            'prodi_id'       => 'nullable|integer',
            'judul_skripsi'  => 'required|string',
            'periode_sidang' => 'required|date',
            'dospem1'        => 'nullable|string|max:255',
            'dospem2'        => 'nullable|string|max:255',
            'pembimbing1'    => 'nullable|string|max:255',
            'pembimbing2'    => 'nullable|string|max:255',
            'dokumen_files.*'=> 'nullable|file|max:20480',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();
        try {
            $validated = $validator->validated();

            if (empty($validated['prodi_id'])) {
                $prodiModel = Prodi::where('nama', $validated['prodi'])
                    ->orWhere('alias', $validated['prodi'])
                    ->first();
                if ($prodiModel) {
                    $validated['prodi_id'] = $prodiModel->id;
                }
            }

            $updateData = [
                'nama'           => $validated['nama'],
                'nim'            => $validated['nim'],
                'nik'            => $validated['nik'] ?? null,
                'prodi'          => $validated['prodi'],
                'prodi_id'       => $validated['prodi_id'] ?? null,
                'judul_skripsi'  => $validated['judul_skripsi'],
                'periode_sidang' => $validated['periode_sidang'],
            ];

            if (array_key_exists('pembimbing1', $validated) || array_key_exists('dospem1', $validated)) {
                $updateData['pembimbing1'] = $validated['pembimbing1'] ?? ($validated['dospem1'] ?? null);
            }
            if (array_key_exists('pembimbing2', $validated) || array_key_exists('dospem2', $validated)) {
                $updateData['pembimbing2'] = $validated['pembimbing2'] ?? ($validated['dospem2'] ?? null);
            }

            $daftarSidang->update($updateData);

            // Unggah dokumen tambahan jika disertakan
            $this->handleDocumentUploads($request, $daftarSidang);

            DB::commit();

            $daftarSidang->load('dokumen');

            return response()->json([
                'status' => true,
                'data' => $daftarSidang,
                'message' => 'Data pendaftaran sidang skripsi berhasil diperbarui'
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Error updating DaftarSidangSkripsi: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Terjadi kesalahan saat mengupdate data: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Menghapus data pendaftaran sidang skripsi beserta seluruh dokumennya.
     */
    public function destroy($id)
    {
        $daftarSidang = DaftarSidangSkripsi::with('dokumen')->find($id);

        if (!$daftarSidang) {
            return response()->json([
                'status' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        try {
            $nim = trim($daftarSidang->nim ?? '');
            $cleanNim = preg_replace('/[^a-zA-Z0-9_\-]/', '', $nim) ?: $nim;

            // Hapus file fisik lokal dan Google Drive jika ada
            foreach ($daftarSidang->dokumen as $doc) {
                if ($doc->local_path && File::exists($doc->local_path)) {
                    @File::delete($doc->local_path);
                }
                if ($doc->drive_file_id) {
                    try {
                        \App\Services\GoogleDrive::deleteFile($doc->drive_file_id);
                    } catch (\Throwable $e) {}
                }
            }

            $prodi = trim($daftarSidang->prodi ?: 'UMUM');
            $cleanProdi = preg_replace('/[\\\\\/:*?"<>|]/', ' ', $prodi);
            $cleanProdi = trim(preg_replace('/\s+/', ' ', $cleanProdi)) ?: 'UMUM';

            // Hapus direktori spesifik mahasiswa ini di Berkas skripsi/{prodi}/{NIM} jika kosong/ada
            if ($cleanProdi && $cleanNim) {
                $folder = storage_path("app/public/Berkas skripsi/{$cleanProdi}/{$cleanNim}");
                if (File::isDirectory($folder)) {
                    @File::deleteDirectory($folder);
                }
            }

            $folderOldNim = storage_path('app/public/Berkas Skripsi/' . $cleanNim);
            if (File::isDirectory($folderOldNim)) {
                @File::deleteDirectory($folderOldNim);
            }

            $folderOld = storage_path('app/public/dokumen_skripsi/' . $daftarSidang->id);
            if (File::isDirectory($folderOld)) {
                @File::deleteDirectory($folderOld);
            }

            $daftarSidang->delete();

            return response()->json([
                'status' => true,
                'message' => 'Data pendaftaran sidang skripsi berhasil dihapus'
            ]);
        } catch (\Throwable $e) {
            Log::error('Error deleting DaftarSidangSkripsi: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Terjadi kesalahan saat menghapus data'
            ], 500);
        }
    }

    /**
     * Endpoint untuk menambah/mengunggah dokumen baru pada pendaftaran yang sudah ada.
     */
    public function uploadDokumen(Request $request, $id)
    {
        $daftarSidang = DaftarSidangSkripsi::find($id);

        if (!$daftarSidang) {
            return response()->json([
                'status' => false,
                'message' => 'Data pendaftaran sidang tidak ditemukan'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'file'         => 'required|file|max:20480',
            'nama_dokumen' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $file = $request->file('file');
            $namaDokumen = $request->input('nama_dokumen');

            $doc = $this->saveSingleDocument($daftarSidang, $file, $namaDokumen);

            return response()->json([
                'status' => true,
                'data' => $doc,
                'message' => 'Dokumen berhasil diunggah'
            ], 201);
        } catch (\Throwable $e) {
            Log::error('Error uploadDokumen: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Gagal mengunggah dokumen: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Endpoint untuk menghapus dokumen spesifik.
     */
    public function deleteDokumen($dokumenId)
    {
        $dokumen = DokumenSkripsi::find($dokumenId);

        if (!$dokumen) {
            return response()->json([
                'status' => false,
                'message' => 'Dokumen tidak ditemukan'
            ], 404);
        }

        try {
            if ($dokumen->local_path && File::exists($dokumen->local_path)) {
                @File::delete($dokumen->local_path);
            }

            if ($dokumen->drive_file_id) {
                try {
                    \App\Services\GoogleDrive::deleteFile($dokumen->drive_file_id);
                } catch (\Throwable $e) {}
            }

            $dokumen->delete();

            return response()->json([
                'status' => true,
                'message' => 'Dokumen berhasil dihapus'
            ]);
        } catch (\Throwable $e) {
            Log::error('Error deleting DokumenSkripsi: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Gagal menghapus dokumen'
            ], 500);
        }
    }

    /**
     * Helper untuk memproses file upload dokumen dari request form.
     */
    protected function handleDocumentUploads(Request $request, DaftarSidangSkripsi $daftarSidang): void
    {
        // 1. Cek jika dikirim dalam bentuk array dokumen_files[*] beserta dokumen_names[*]
        if ($request->hasFile('dokumen_files')) {
            $files = $request->file('dokumen_files');
            $names = $request->input('dokumen_names', []);

            foreach ($files as $index => $file) {
                if ($file && $file->isValid()) {
                    $docName = $names[$index] ?? pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
                    $this->saveSingleDocument($daftarSidang, $file, $docName);
                }
            }
        }

        // 2. Cek jika dikirim sebagai dokumen[index][file] & dokumen[index][nama_dokumen]
        if ($request->has('dokumen') && is_array($request->dokumen)) {
            foreach ($request->dokumen as $index => $docData) {
                if ($request->hasFile("dokumen.{$index}.file")) {
                    $file = $request->file("dokumen.{$index}.file");
                    $docName = $docData['nama_dokumen'] ?? pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
                    $this->saveSingleDocument($daftarSidang, $file, $docName);
                }
            }
        }
    }

    /**
     * Simpan satu file fisik ke storage lokal dan dispatch job ke Google Drive.
     * File disimpan di: Berkas skripsi/{prodi}/{NIM} baik di lokal maupun Google Drive.
     */
    protected function saveSingleDocument(DaftarSidangSkripsi $daftarSidang, $uploadedFile, string $namaDokumen): DokumenSkripsi
    {
        $extension = $uploadedFile->getClientOriginalExtension() ?: 'pdf';
        $safeName = Str::slug($namaDokumen) ?: 'dokumen';
        $fileName = time() . '_' . Str::random(6) . "_{$safeName}.{$extension}";

        $prodi = trim($daftarSidang->prodi ?: 'UMUM');
        $cleanProdi = preg_replace('/[\\\\\/:*?"<>|]/', ' ', $prodi);
        $cleanProdi = trim(preg_replace('/\s+/', ' ', $cleanProdi)) ?: 'UMUM';

        $nim = trim($daftarSidang->nim ?? '');
        $cleanNim = preg_replace('/[^a-zA-Z0-9_\-]/', '', $nim) ?: ($nim ?: 'UNKNOWN_' . $daftarSidang->id);

        // Direktori lokal: storage/app/public/Berkas skripsi/{prodi}/{NIM}
        $directory = storage_path("app/public/Berkas skripsi/{$cleanProdi}/{$cleanNim}");
        if (!File::isDirectory($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        $uploadedFile->move($directory, $fileName);
        $localPath = "{$directory}/{$fileName}";

        $dokumen = DokumenSkripsi::create([
            'daftar_sidang_skripsi_id' => $daftarSidang->id,
            'nama_dokumen'             => $namaDokumen,
            'local_path'               => $localPath,
            'status'                   => 'pending',
        ]);

        // Dispatch Job untuk upload ke Google Drive di folder: Berkas skripsi/{prodi}/{NIM}
        try {
            $driveFolderPath = "Berkas skripsi/{$cleanProdi}/{$cleanNim}";
            UploudSuratToDrive::dispatch(
                $dokumen->id,
                'Dokumen Sidang Skripsi',
                $cleanProdi,
                DokumenSkripsi::class,
                $driveFolderPath
            );
        } catch (\Throwable $ex) {
            Log::warning('Dispatch upload to drive failed: ' . $ex->getMessage());
        }

        return $dokumen;
    }
}

